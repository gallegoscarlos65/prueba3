class Semana {
  Semana({this.dia, this.monto});

  final String? dia;
  final double? monto;
}
