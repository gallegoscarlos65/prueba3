class Gastos {
  String? concepto;
  double? cantidad;
  DateTime? fecha;
  Gastos({required this.concepto, required this.cantidad, required this.fecha});

  setGastos(String concepto, double cantidad, DateTime fecha){
    this.concepto = concepto;
    this.cantidad = cantidad;
    this.fecha = fecha;
  }
}
