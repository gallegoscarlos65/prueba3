import 'package:flutter/material.dart';
import 'package:gastos/config.dart';
import 'package:gastos/widgets/barritas.dart';
import 'package:intl/intl.dart';
import 'database/gastos.dart';
import 'database/semana.dart';
import 'widgets/bitacora.dart';
import 'widgets/format.dart';

class Run extends StatefulWidget {
  const Run({Key? key}) : super(key: key);

  @override
  State<Run> createState() => _RunState();
}

class _RunState extends State<Run> {
  final TextEditingController cantidadController = TextEditingController();
  final TextEditingController concepController = TextEditingController();
  final TextEditingController dateController = TextEditingController();

  void formaDatos() async {
    return await showModalBottomSheet(
        elevation: 5,
        isScrollControlled: true,
        context: context,
        builder: (_) => formatoRegistro(concepController, cantidadController, dateController,context, _agregarGasto));
  }

  List<Gastos> get gastosSemana {
    return losgastos
        .where((gasto) =>
            gasto.fecha!.isAfter(DateTime.now().subtract(const Duration(days: 7))))
        .toList();
  }

  void _agregarGasto() {
    Gastos gasto = Gastos(
        concepto: concepController.text,
        cantidad: double.parse(cantidadController.text),
        fecha: DateTime.parse(dateController.text.toString()));
    setState(() {
      losgastos.add(gasto);
      _rellenar();
      semana = _sumaGastosSemana();
    });
    debugPrint(losgastos.toString());
    Navigator.pop(context);
    cantidadController.clear();
    concepController.clear();
    dateController.clear();
  }

  void _rellenar() {
    losgastos = gastosSemana;
    debugPrint(losgastos.toString());
  }

  List<Semana> _sumaGastosSemana() {
    return List.generate(7, (index) {
      DateTime hoy = DateTime.now().subtract(Duration(days: index));
      double suma = 0;
      List<Gastos> gasto = gastosSemana;

      for (int i = 0; i < gasto.length; i++) {
        if (gasto[i].fecha!.day == hoy.day) {
          suma += gasto[i].cantidad!;
        }
      }
      return Semana(
          dia: DateFormat('EEE').format(hoy).substring(0, 1), monto: suma);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: <Widget>[
          IconButton(onPressed: () => formaDatos(), icon: const Icon(Icons.add)),
          IconButton(
              onPressed: () => themach.cambiarTema(),
              icon: const Icon(Icons.dark_mode))
        ],
        title: const Text("Gastos"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              width: double.infinity,
              child: Barritas(),
            ),
            SizedBox(height: 500, width: double.infinity, child: Bitacora()),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () => formaDatos(), child: const Icon(Icons.add)),
    );
  }
}//end class
